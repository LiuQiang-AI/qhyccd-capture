from .qhyccd_capture import CameraControlWidget
__version__ = "0.0.3.5"


